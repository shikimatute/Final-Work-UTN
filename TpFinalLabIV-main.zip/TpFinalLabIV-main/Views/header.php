<!DOCTYPE html>
<html lang="es">
<head>
  <title>PET HERO</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link href="<?php echo CSS_PATH;?>layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top" styles="font-family: 'Montserrat', sans-serif;">