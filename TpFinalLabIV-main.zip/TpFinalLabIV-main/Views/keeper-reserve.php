<?php

    require_once('header.php');
    require_once('keeper-nav-bar.php');

?>

<main>
    <div>
        <h1 align="center">NOT AVAILABLE FUNCTIONALITY YET</h1>
    </div>
</main>

<?php

    /*require_once('footer.php');*/

?>