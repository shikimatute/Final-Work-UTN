<footer id="footer" class="hoc clear"> 
    <div class="center">
      <h6 class="heading">Pet Hero</h6> 
      <nav>
        <ul class="nospace inline pushright uppercase">
          <li><a href="<?php echo FRONT_ROOT ?>"><i class="fas fa-lg fa-home"></i></a></li>
          <li><a href="<?php echo FRONT_ROOT ?>">Home</a></li>
          <li><a href="<?php echo FRONT_ROOT?>User/showListView">Users</a></li>
          <li><a href="<?php echo FRONT_ROOT?>UserType/showListView">User Types</a></li>
        </ul>
      </nav>
    </div>
  </footer>
</div>
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <p align="center">Copyright &copy; <?php echo date('Y'); ?> - All Rights Reserved - UTN Mar del Plata</p>
  </div>
</div>
<a id="backtotop" href="#top"><i class="fas fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="<?php echo JS_PATH ?>jquery.min.js"></script>
<script src="<?php echo JS_PATH ?>jquery.backtotop.js"></script>
<script src="<?php echo JS_PATH ?>jquery.mobilemenu.js"></script>
</body>
</html>