<?php 
  include_once('header.php');
  include_once('nav-bar.php');
?>





<?php 
  require_once(VIEWS_PATH."footer.php");
?>